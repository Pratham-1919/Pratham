﻿namespace Mission.Entities.ViewModels.MissionTheme
{
    public class MissionThemeViewModel
    {
        public int Id { get; set; }
        public string ThemeName { get; set; }
        public string Status { get; set; }
    }
}
