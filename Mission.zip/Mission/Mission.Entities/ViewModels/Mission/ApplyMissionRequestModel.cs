﻿namespace Mission.Entities.ViewModels.Mission
{
    public class ApplyMissionRequestModel
    {
        public int MissionId { get; set; }
        public DateTime AppliedDate { get; set; }
        public int UserId { get; set; }
    }
}
